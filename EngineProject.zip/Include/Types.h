#pragma once

typedef struct _tagResolution
{
	unsigned int nWidth;
	unsigned int nHeight;
}RESOLUTION, *PRESOLUTION;
